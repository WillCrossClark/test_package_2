import requests

def get_user():
    print('this would get a user')

def get_position():
    print('this would get a position')